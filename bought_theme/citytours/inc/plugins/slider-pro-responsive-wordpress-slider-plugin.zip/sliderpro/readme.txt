Thank you for purchasing Slider Pro!

To install the plugin, please go to Plugins -> Add New -> Upload in your WordPress Dashboard, and upload the zip package downloaded from CodeCanyon.

For usage instructions please see the documentation included.

The 'examples' folder contains several examples that you can import into your own installation.